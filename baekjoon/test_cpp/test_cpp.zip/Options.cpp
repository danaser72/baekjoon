#include "Options.h"

int Options::getCost() {
	return 0;
}
string Options::getDescription() {
	return "Options";
}