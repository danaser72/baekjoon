#include "BaseCar.h"


int BaseCar::getCost() {
	return 10000000;
}
string BaseCar::getDescription() {
	return "BaseCar";
}