#include <iostream>
#include "App.h"


int main() {
	App app;
	app.menu();

	return 0;
}